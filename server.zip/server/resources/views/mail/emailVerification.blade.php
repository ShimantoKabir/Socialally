<html>
<head>
    <title></title>
</head>
<body>
<div>
    <a href="{{$verificationLink}}" >Click here to active your account.</a>
</div>
</body>
</html>

<html>
<head>
    <title></title>
</head>
<body>
<div>
    <a href="<?php echo e($verificationLink); ?>" >Click here to active your account.</a>
</div>
</body>
</html>
<?php /**PATH C:\Projects\server\resources\views/mail/emailVerification.blade.php ENDPATH**/ ?>